var Productos = require('./productos');

var productos = new Productos('heraym');
productos.demoProducto("Oracle Process Cloud Service", callback);

function callback(detalleProducto) {
 console.log(detalleProducto);
}