var Productos = require('./productos');

var productos = new Productos('heraym');
productos.demos(callback);

function callback(demos) {
 for (var i = 0; i < demos.length; i++) {
    console.log(demos[i]);
 }
}