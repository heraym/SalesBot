var moduleName = 'Productos';
var fs = require('fs'); 
var parse = require('csv-parse');
var Promise = require("bluebird");


var Productos = function (userId) {
    this.userId = userId;
};

Productos.prototype.preciosProducto = function (idProducto, callback) {

var csvData=[];
fs.createReadStream("./Precios.csv")
    .pipe(parse({delimiter: ';', columns: true}))
    .on('data', function(csvrow) {
         //do something with csvrow
        if (idProducto == csvrow.Categoria) 
           { callback(csvrow);}
        csvData.push(csvrow);        
    })
    .on('end',function() {
      //do something wiht csvData
      //console.log(csvData);
    });
}

Productos.prototype.categoriasProducto = function (callback) {

var csvData=[];
fs.createReadStream("./Categorias.csv")
    .pipe(parse({delimiter: ';', columns: true}))
    .on('data', function(csvrow) {
         //do something with csvrow
        csvData.push(csvrow);        
    })
    .on('end',function() {
      //do something wiht csvData
      callback(csvData);
    });
}

Productos.prototype.demos = function (callback) {

var csvData=[];
fs.createReadStream("./Demos.csv")
    .pipe(parse({delimiter: ';', columns: true}))
    .on('data', function(csvrow) {
         //do something with csvrow
        csvData.push(csvrow);        
    })
    .on('end',function() {
      //do something wiht csvData
      callback(csvData);
    });
}

Productos.prototype.demoProducto = function (idProducto, callback) {

var csvData=[];
fs.createReadStream("./Demos.csv")
    .pipe(parse({delimiter: ';', columns: true}))
    .on('data', function(csvrow) {
         //do something with csvrow
        if (idProducto == csvrow.Categoria) { callback(csvrow); }
        csvData.push(csvrow);        
    })
    .on('end',function() {
      //do something wiht csvData
    });
}


module.exports = Productos;
