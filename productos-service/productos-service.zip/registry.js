'use strict';

module.exports = {
  components: {
   'ar.cloud.categoriasLinea' : require('./chatbot/categoriasLinea'),
   'ar.cloud.familiasCategoria' : require('./chatbot/familiasCategoria')
  }
};
